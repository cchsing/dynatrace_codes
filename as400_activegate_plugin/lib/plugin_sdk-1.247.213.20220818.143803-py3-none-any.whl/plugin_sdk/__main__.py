from plugin_sdk.main import main
main()