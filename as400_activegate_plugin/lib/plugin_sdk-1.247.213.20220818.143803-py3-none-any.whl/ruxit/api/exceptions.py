"""
Exceptions hierarchy usable by plugins. Those errors are not raised automatically, but plugin developers
can use them to hint certain categories of errors.
"""


class AuthException(Exception):
    """
    Should be raised when problems with getting required access are detected and identified as
    being caused by insufficient/invalid permissions (e.g. wrong db password)
    """
    pass


class ConfigException(Exception):
    """
    Should be used when a general configuration error is detected (e.g. no reponse when trying to connect
    to an endpoint specified by the user. Messages from this exception are passed in plugin status.
    """
    pass


class NothingToReportException(Exception):
    """
    Should be used when a plugin detects a situation where it was activated, but has no data to report, e.g.

     - A plugin is using broad activation triggers - all Java processes - but is interested only in a specific
       application e.g elasticsearch
     - A plugin monitors a process that report new stats on an infrequent basic - like once every hour.
     - Monitored process is not configured to expose any metrics
    """
    pass
