import collections
from ruxit.api.snapshot import get_technologies
from ruxit.platform.platform_api import EntityResolverIfc


class EntityResolver(EntityResolverIfc):
    def __init__(self):
        self.process_snapshot = None
        self.snapshot_by_process_type = collections.defaultdict(list)
        self.snapshot_by_technology = collections.defaultdict(list)
        self.docker_entity_map = {}

    def set_snapshot(self, process_snapshot):
        self.process_snapshot = process_snapshot
        self.snapshot_by_process_type.clear()
        self.snapshot_by_technology.clear()
        for se in process_snapshot.entries:
            self.snapshot_by_process_type[se.process_type].append(se)
            for techno in get_technologies(se):
                if len (techno) == 0:
                    continue
                self.snapshot_by_technology[techno].append(se)
        self.docker_entity_map = {c.container_id: c.docker_container_group_instance_id for c in process_snapshot.containers}

    def get_snapshot(self):
        return self.process_snapshot

    def resolve(self, selector, **kwargs):
        return selector.select_id(
            process_snapshot=self.process_snapshot,
            snapshot_by_process_type=self.snapshot_by_process_type,
            snapshot_by_technology = self.snapshot_by_technology,
            docker_entity_map=self.docker_entity_map,
            **kwargs
        )
