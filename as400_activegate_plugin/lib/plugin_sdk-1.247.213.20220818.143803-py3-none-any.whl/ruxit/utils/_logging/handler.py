import logging

#handler to forward logs into native part
class EngineLogHandler(logging.Handler):
    _level_mapping = {
        logging.NOTSET: 8,
        logging.DEBUG: 7,
        logging.INFO: 4,
        logging.WARNING: 5,
        logging.ERROR: 6,
        logging.FATAL: 6,
    }

    def __init__(self, api_log):
        super().__init__()
        self.api_log = api_log

    def emit(self, record):
        msg = self.format(record).encode('ascii', errors='replace')
        self.api_log(self._level_mapping[record.levelno], msg)


#creates log handler for local plugin engine
def embedded_log_handler():
    import embedded_api
    return EngineLogHandler(embedded_api.api_object.log)

#creates log handler for RPM
def remote_log_handler():
    import remote_embedded_api
    return EngineLogHandler(remote_embedded_api.api_object.log)
